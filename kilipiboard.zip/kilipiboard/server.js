// server.js - Multi-device Samtronics Controller
const express = require("express");
const fs = require("fs");
const path = require("path");
const cors = require("cors");

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.text());
app.use(express.urlencoded({ extended: true }));

// Directory to hold all device message files
const deviceDir = path.join(__dirname, "device_data");
if (!fs.existsSync(deviceDir)) fs.mkdirSync(deviceDir);

// ===================================================
// ROUTE: GET message for ESP8266
// Example: /message?id=device1
// ===================================================
app.get("/message", (req, res) => {
  const id = req.query.id;
  if (!id) return res.status(400).send("Missing ?id parameter");

  const file = path.join(deviceDir, `${id}.txt`);

  if (!fs.existsSync(file)) {
    fs.writeFileSync(file, "NO_MESSAGE");
  }

  fs.readFile(file, "utf8", (err, data) => {
    if (err) {
      console.error("❌ Error reading file:", err);
      return res.status(500).send("ERROR");
    }

    console.log(`📡 [${new Date().toLocaleTimeString()}] ${id} fetched: ${data.trim()}`);
    res.type("text/plain").send(data.trim());
  });
});

// ===================================================
// ROUTE: POST update message for a device
// ===================================================
app.post("/update", (req, res) => {
  const id = req.body.id?.trim();
  const message = req.body.message?.trim();

  if (!id || !message) return res.status(400).send("Missing id or message");

  const file = path.join(deviceDir, `${id}.txt`);
  fs.writeFile(file, message, (err) => {
    if (err) {
      console.error("❌ Write error:", err);
      return res.status(500).send("Failed");
    }
    console.log(`✅ Updated ${id}: ${message}`);
    res.redirect("/");
  });
});

// ===================================================
// ROUTE: Dashboard Page
// ===================================================
app.get("/", (req, res) => {
  const files = fs.readdirSync(deviceDir).filter(f => f.endsWith(".txt"));

  let rows = files.map(f => {
    const id = f.replace(".txt", "");
    const msg = fs.readFileSync(path.join(deviceDir, f), "utf8").trim();
    return `
      <tr>
        <td>${id}</td>
        <td><code>${msg}</code></td>
        <td>
          <form action="/update" method="POST" style="display:flex; gap:5px;">
            <input type="hidden" name="id" value="${id}">
            <input type="text" name="message" placeholder="New message" style="flex:1; padding:5px;">
            <button type="submit">Update</button>
          </form>
        </td>
      </tr>
    `;
  }).join("");

  res.send(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>Samtronics Multi-Device Dashboard</title>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <style>
        body { font-family: Arial; background:#0d1117; color:#c9d1d9; padding:20px; }
        h1 { color:#58a6ff; text-align:center; }
        table { width:100%; border-collapse:collapse; margin-top:20px; background:#161b22; }
        th, td { border:1px solid #30363d; padding:10px; text-align:left; }
        th { background:#21262d; }
        input, button { border:none; border-radius:5px; }
        input { background:#21262d; color:#c9d1d9; padding:6px; }
        button { background:#238636; color:white; padding:6px 12px; cursor:pointer; }
        button:hover { background:#2ea043; }
        .add { text-align:center; margin-top:25px; }
      </style>
    </head>
    <body>
      <h1>🧠 Samtronics Multi-Device Dashboard</h1>
      <table>
        <tr><th>Device ID</th><th>Current Message</th><th>Update</th></tr>
        ${rows || '<tr><td colspan="3" style="text-align:center;">No devices yet</td></tr>'}
      </table>
      <div class="add">
        <h3>Add / Update Device</h3>
        <form action="/update" method="POST">
          <input type="text" name="id" placeholder="device1" required>
          <input type="text" name="message" placeholder="Message" required>
          <button type="submit">Save</button>
        </form>
      </div>
    </body>
    </html>
  `);
});

// ===================================================
// START SERVER
// ===================================================
app.listen(PORT, () => {
  console.log(`✅ Samtronics Server Live at: https://sevensegment.onrender.com`);
  console.log(`📡 Endpoint for ESP8266: https://sevensegment.onrender.com/message?id=device1`);
});
